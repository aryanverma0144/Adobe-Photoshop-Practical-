# Practical 06 — Tech Fest 2026

## Student Details
- Name: Aryan Verma
- Roll Number: 55
- Course: BCA

## Objective
To complete the practical 06 practical using Adobe Photoshop tools.

## Tools / techniques
- Layers and selection tools
- Text and shape tools
- Color correction and effects (as applicable)

## Output
The included JPG is a simple starter/reference design. Open or recreate it in Adobe Photoshop, use the required tools from the assignment, and save an editable PSD file before submission.

## Files
- `Practical_06_Aryan_Verma.jpg` — JPG reference/export
- `Practical_06_Aryan_Verma.psd` — save this editable file from Photoshop
